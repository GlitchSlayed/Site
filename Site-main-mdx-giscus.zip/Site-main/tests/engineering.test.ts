// Tests for the engineering model layer (pure TypeScript, independent of rendering).
import { describe, it, expect } from 'vitest';
import { liftModel } from '../src/lib/engineering/models/aerodynamics/lift';
import { dragPolarModel } from '../src/lib/engineering/models/aerodynamics/dragPolar';
import { aircraftPerformanceModel } from '../src/lib/engineering/models/aircraft-performance/bwb';
import {
  safeDivide,
  safeResult,
  significantFigures,
  validateInputs,
  clamp,
} from '../src/lib/engineering/validation';
import { convert, UNITS } from '../src/lib/engineering/units';
import { formatResult, formatPercentageChange, MAX_DECIMALS } from '../src/lib/engineering/format';
import { formatNumber } from '../src/lib/engineering/format';
import { getModel } from '../src/lib/engineering/registry';
import { getPlotDefinition } from '../src/lib/engineering/plots/registry';
import rehypeEngineeringAnnotations from '../src/lib/rehype/rehypeEngineeringAnnotations';

describe('lift model', () => {
  it('computes lift for standard conditions', () => {
    const out = liftModel.compute({
      rho: 1.225,
      velocity: 50,
      area: 20,
      cl: 0.5,
    });
    // L = 0.5 * 1.225 * 50^2 * 20 * 0.5 = 15312.5 N
    expect(out.lift.value).toBeCloseTo(15312.5, 4);
  });

  it('handles zero velocity safely', () => {
    const out = liftModel.compute({
      rho: 1.225,
      velocity: 0,
      area: 20,
      cl: 0.5,
    });
    expect(out.lift.value).toBe(0);
  });

  it('computes reference lift case: 61250 N', () => {
    // L = 0.5 * rho * V^2 * S * C_L = 0.5 * 1.225 * 100^2 * 20 * 0.5 = 61250 N
    const out = liftModel.compute({
      rho: 1.225,
      velocity: 100,
      area: 20,
      cl: 0.5,
    });
    expect(out.lift.value).toBeCloseTo(61250, 4);
  });

  it('lift scales linearly with density, area, and cl, quadratically with velocity', () => {
    const base = liftModel.compute({ rho: 1.225, velocity: 100, area: 20, cl: 0.5 }).lift.value!;
    const doubleDensity = liftModel.compute({ rho: 2.45, velocity: 100, area: 20, cl: 0.5 }).lift.value!;
    const doubleArea = liftModel.compute({ rho: 1.225, velocity: 100, area: 40, cl: 0.5 }).lift.value!;
    const doubleCL = liftModel.compute({ rho: 1.225, velocity: 100, area: 20, cl: 1.0 }).lift.value!;
    const doubleVelocity = liftModel.compute({ rho: 1.225, velocity: 200, area: 20, cl: 0.5 }).lift.value!;

    expect(doubleDensity).toBeCloseTo(base * 2, 4);
    expect(doubleArea).toBeCloseTo(base * 2, 4);
    expect(doubleCL).toBeCloseTo(base * 2, 4);
    expect(doubleVelocity).toBeCloseTo(base * 4, 4);
  });

  it('is registered in the model registry', () => {
    expect(getModel('aerodynamics.lift')).toBe(liftModel);
  });
});

describe('drag polar model', () => {
  it('computes k and C_D correctly', () => {
    const out = dragPolarModel.compute({ cd0: 0.02, e: 0.8, ar: 10, cl: 0.5 });
    // k = 1 / (pi * 0.8 * 10) = 0.039788...
    expect(out.k.value).toBeCloseTo(1 / (Math.PI * 0.8 * 10), 6);
    // C_D = 0.02 + k * 0.5^2
    const k = 1 / (Math.PI * 0.8 * 10);
    expect(out.cd.value).toBeCloseTo(0.02 + k * 0.25, 6);
  });

  it('handles e=0 safely (division by zero -> fallback)', () => {
    const out = dragPolarModel.compute({ cd0: 0.02, e: 0, ar: 10, cl: 0.5 });
    // e=0 => k fallback to 0 => C_D = cd0
    expect(out.k.value).toBe(0);
    expect(out.cd.value).toBe(0.02);
  });

  it('is symmetric in |C_L| (drag depends on C_L^2)', () => {
    const pos = dragPolarModel.compute({ cd0: 0.02, e: 0.8, ar: 10, cl: 0.8 }).cd.value;
    const neg = dragPolarModel.compute({ cd0: 0.02, e: 0.8, ar: 10, cl: -0.8 }).cd.value;
    expect(pos).toBeCloseTo(neg, 6);
  });

  it('drag polar: C_D = C_D,0 when C_L = 0', () => {
    const out = dragPolarModel.compute({ cd0: 0.02, e: 0.8, ar: 10, cl: 0 });
    expect(out.cd.value).toBeCloseTo(0.02, 6);
  });

  it('drag polar: C_D varies quadratically with C_L', () => {
    const cd0 = 0.02;
    const e = 0.8;
    const ar = 10;
    const k = 1 / (Math.PI * e * ar);

    const cl1 = 0.5;
    const cl2 = 1.0;
    const cd1 = dragPolarModel.compute({ cd0, e, ar, cl: cl1 }).cd.value!;
    const cd2 = dragPolarModel.compute({ cd0, e, ar, cl: cl2 }).cd.value!;

    // C_D = C_D,0 + k * C_L^2
    expect(cd1).toBeCloseTo(cd0 + k * cl1 * cl1, 6);
    expect(cd2).toBeCloseTo(cd0 + k * cl2 * cl2, 6);

    // Quadratic: doubling C_L should quadruple the k*C_L^2 term
    const induced1 = cd1 - cd0;
    const induced2 = cd2 - cd0;
    expect(induced2).toBeCloseTo(induced1 * 4, 6);
  });

  it('drag polar: changing e, AR, or C_D,0 changes C_D', () => {
    const base = { cd0: 0.02, e: 0.8, ar: 10, cl: 0.5 };
    const baseCd = dragPolarModel.compute(base).cd.value!;

    // Different e
    const cdDiffE = dragPolarModel.compute({ ...base, e: 0.9 }).cd.value!;
    expect(cdDiffE).not.toBeCloseTo(baseCd, 6);

    // Different AR
    const cdDiffAr = dragPolarModel.compute({ ...base, ar: 12 }).cd.value!;
    expect(cdDiffAr).not.toBeCloseTo(baseCd, 6);

    // Different C_D,0
    const cdDiffCd0 = dragPolarModel.compute({ ...base, cd0: 0.03 }).cd.value!;
    expect(cdDiffCd0).not.toBeCloseTo(baseCd, 6);
  });

  it('drag polar: higher e reduces induced drag', () => {
    const cdLowE = dragPolarModel.compute({ cd0: 0.02, e: 0.6, ar: 10, cl: 0.8 }).cd.value!;
    const cdHighE = dragPolarModel.compute({ cd0: 0.02, e: 0.9, ar: 10, cl: 0.8 }).cd.value!;
    expect(cdHighE).toBeLessThan(cdLowE);
  });
});

describe('aircraft performance model', () => {
  const base = {
    mass: 70000,
    structuralPenalty: 0,
    area: 300,
    ar: 9,
    e: 0.8,
    cd0: 0.02,
    inducedCorrection: 1,
    rho: 1.225,
    velocity: 80,
  };

  it('computes steady level flight values', () => {
    const out = aircraftPerformanceModel.compute(base);
    const weight = 70000 * 9.80665;
    const q = 0.5 * 1.225 * 80 * 80;
    const cl = weight / (q * 300);
    const k = 1 / (Math.PI * 0.8 * 9);
    const cd = 0.02 + k * cl * cl;
    expect(out.weight.value).toBeCloseTo(weight, 2);
    expect(out.cl.value).toBeCloseTo(cl, 4);
    expect(out.k.value).toBeCloseTo(k, 6);
    expect(out.cd.value).toBeCloseTo(cd, 4);
    expect(out.ld.value).toBeCloseTo(cl / cd, 4);
    expect(out.thrust.value).toBeCloseTo(q * 300 * cd, 2);
    // Thrust equals drag in steady level flight.
    expect(out.thrust.value).toBeCloseTo(out.drag.value, 4);
  });

  it('structural mass penalty raises required C_L and drag', () => {
    // Use velocity=60 so required C_L exceeds the L/D-optimal point (~0.67),
    // ensuring added mass reduces L/D.
    const lowSpeedBase = { ...base, velocity: 60 };
    const baseline = aircraftPerformanceModel.compute({ ...lowSpeedBase, structuralPenalty: 0 });
    const penalized = aircraftPerformanceModel.compute({ ...lowSpeedBase, structuralPenalty: 0.2 });
    expect(penalized.cl.value).toBeGreaterThan(baseline.cl.value);
    expect(penalized.cd.value).toBeGreaterThan(baseline.cd.value);
    expect(penalized.ld.value).toBeLessThan(baseline.ld.value);
    expect(penalized.totalMass.value).toBeCloseTo(70000 * 1.2, 4);
  });

  it('guards against zero/negative area', () => {
    const out = aircraftPerformanceModel.compute({ ...base, area: 0 });
    expect(Number.isFinite(out.cl.value)).toBe(true);
    expect(out.cl.value).toBe(0);
  });

  it('L/D = C_L / C_D identity', () => {
    const out = aircraftPerformanceModel.compute(base);
    expect(out.ld.value).toBeCloseTo(out.cl.value / out.cd.value, 4);
  });

  it('lift equals weight in steady level flight', () => {
    const out = aircraftPerformanceModel.compute(base);
    // In steady level flight, L = W = m_total * g
    expect(out.lift.value).toBeCloseTo(out.weight.value, 4);
  });

  it('geometry consistency: AR = b^2 / S', () => {
    // With span=45, area=300: AR = 45^2/300 = 6.75
    const out = aircraftPerformanceModel.compute({ ...base, ar: 6.75 });
    const expectedAR = (45 * 45) / 300;
    expect(expectedAR).toBeCloseTo(6.75, 4);
    // The induced-drag factor uses the provided AR
    const k = 1 / (Math.PI * 0.8 * expectedAR);
    expect(out.k.value).toBeCloseTo(k, 6);
  });

  it('default AR fallback matches parameter default (6.75)', () => {
    // compute() destructures ar with default 6.75 (matching parameter default)
    const { ar: _, ...withoutAr } = base;
    const out = aircraftPerformanceModel.compute(withoutAr);
    const k = 1 / (Math.PI * 0.8 * 6.75);
    expect(out.k.value).toBeCloseTo(k, 6);
  });

  it('derives AR dynamically from span and area when span is given', () => {
    // If span=60 and area=300 without explicit ar: AR = 60^2 / 300 = 12.0
    const { ar: _, ...withoutAr } = base;
    const out = aircraftPerformanceModel.compute({ ...withoutAr, span: 60, area: 300 });
    const expectedAR = (60 * 60) / 300; // 12.0
    const expectedK = 1 / (Math.PI * 0.8 * expectedAR);
    expect(out.k.value).toBeCloseTo(expectedK, 6);
  });

  it('structural mass penalty reduces L/D through increased required C_L', () => {
    // Use velocity=60 so required C_L exceeds the L/D-optimal point (~0.67),
    // ensuring added mass reduces L/D.
    const lowSpeedBase = { ...base, velocity: 60 };
    const baseline = aircraftPerformanceModel.compute({ ...lowSpeedBase, structuralPenalty: 0 });
    const penalized = aircraftPerformanceModel.compute({ ...lowSpeedBase, structuralPenalty: 0.2 });
    expect(penalized.cl.value).toBeGreaterThan(baseline.cl.value);
    expect(penalized.cd.value).toBeGreaterThan(baseline.cd.value);
    expect(penalized.ld.value).toBeLessThan(baseline.ld.value);
    expect(penalized.totalMass.value).toBeCloseTo(70000 * 1.2, 4);
  });
});

describe('validation', () => {
  it('safeDivide returns fallback for zero denominator', () => {
    expect(safeDivide(10, 0, -1)).toBe(-1);
    expect(safeDivide(10, 1e-12, -1)).toBe(-1);
    expect(safeDivide(10, 2)).toBe(5);
  });

  it('safeResult returns fallback for non-finite', () => {
    expect(safeResult(Infinity, -1)).toBe(-1);
    expect(safeResult(NaN, -1)).toBe(-1);
    expect(safeResult(42, -1)).toBe(42);
  });

  it('significantFigures rounds correctly', () => {
    expect(significantFigures(1234.56, 3)).toBe(1230);
    expect(significantFigures(0.004567, 2)).toBeCloseTo(0.0046, 6);
    expect(significantFigures(0, 3)).toBe(0);
    expect(significantFigures(Infinity, 3)).toBe(Infinity);
  });

  it('validateInputs clamps out-of-range and reports errors', () => {
    const params = [
      { id: 'a', label: 'A', min: 0, max: 10, step: 1, defaultValue: 5 },
    ];
    const { values, errors } = validateInputs({ a: 99 }, params);
    expect(values.a).toBe(10);
    expect(errors.a).toBeDefined();
  });

  it('validateInputs uses defaults for missing values', () => {
    const params = [
      { id: 'a', label: 'A', min: 0, max: 10, step: 1, defaultValue: 5 },
    ];
    const { values } = validateInputs({}, params);
    expect(values.a).toBe(5);
  });

  it('clamp bounds a value', () => {
    expect(clamp(5, 0, 10)).toBe(5);
    expect(clamp(-3, 0, 10)).toBe(0);
    expect(clamp(15, 0, 10)).toBe(10);
  });
});

describe('unit conversions', () => {
  it('converts knots to m/s and back', () => {
    const mps = convert(100, 'kt', 'm/s');
    expect(mps).toBeCloseTo(100 * 0.514444, 6);
    expect(convert(mps, 'm/s', 'kt')).toBeCloseTo(100, 6);
  });

  it('converts feet to meters', () => {
    expect(convert(10, 'ft', 'm')).toBeCloseTo(3.048, 6);
  });

  it('returns input for unknown or mismatched units', () => {
    expect(convert(5, 'm', 'kg')).toBe(5);
    expect(convert(5, 'nope', 'm')).toBe(5);
  });

  it('UNITS exposes SI density and speed', () => {
    expect(UNITS['kg/m³'].dimension).toBe('density');
    expect(UNITS['m/s'].dimension).toBe('speed');
  });
});

describe('model registry', () => {
  it('lists all registered models', () => {
    expect(getModel(liftModel.id)).toBeDefined();
    expect(getModel(dragPolarModel.id)).toBeDefined();
    expect(getModel(aircraftPerformanceModel.id)).toBeDefined();
    expect(getModel('nonexistent')).toBeUndefined();
  });

  it('aircraft performance model has expected presets', () => {
    const model = getModel(aircraftPerformanceModel.id);
    expect(model?.presets?.conventional).toBeDefined();
    expect(model?.presets?.bwbOptimistic).toBeDefined();
    expect(model?.presets?.bwbPenalized).toBeDefined();
  });
});

describe('format', () => {
  it('formatPercentageChange returns parenthesized values', () => {
    expect(formatPercentageChange(115, 100)).toBe('(+15%)');
    expect(formatPercentageChange(85, 100)).toBe('(-15%)');
    expect(formatPercentageChange(80.8, 100)).toBe('(-19.2%)');
    expect(formatPercentageChange(115.5, 100)).toBe('(+15.5%)');
    expect(formatPercentageChange(100, 100)).toBe('(+0%)');
    expect(formatPercentageChange(100, 0)).toBeNull();
    expect(formatPercentageChange(NaN, 100)).toBeNull();
  });

  it('formatResult auto-scales N to kN for large values', () => {
    const out = formatResult({
      value: 686500,
      unit: 'N',
      label: 'Required Lift',
      significantFigures: 4,
    });
    expect(out.value).toBe('686.5');
    expect(out.unit).toBe('kN');
    expect(out.displayText).toContain('kN');
  });

  it('formatResult shows dimensionless values without unit brackets', () => {
    const out = formatResult({
      value: 0.527,
      unit: '-',
      label: 'Lift coefficient',
      significantFigures: 3,
    });
    expect(out.unit).toBe('-');
    expect(out.displayText).toBe('Lift coefficient: 0.527');
  });

  it('formatResult preserves full precision internally, rounds for display only', () => {
    const out = formatResult({
      value: 12345.6789,
      unit: 'N',
      significantFigures: 4,
    });
    expect(out.value).toBe('12.35');
    expect(out.unit).toBe('kN');
    expect(out.displayText).toContain('kN');
  });

  it('formatResult caps decimal places at MAX_DECIMALS (5)', () => {
    const out = formatResult({
      value: 0.373492847,
      unit: '-',
      label: 'Test coefficient',
      significantFigures: 10,
    });
    expect(out.value).toBe('0.37349');
  });

  it('formatResult removes trailing zeros', () => {
    const out = formatResult({
      value: 0.800000000,
      unit: '-',
      label: 'Efficiency',
      significantFigures: 10,
    });
    expect(out.value).toBe('0.8');
  });

  it('formatResult uses four decimal places for ordinary values', () => {
    const out = formatResult({
      value: 14.56789123,
      unit: '-',
      label: 'L/D',
      significantFigures: 10,
    });
    expect(out.value).toBe('14.56789');
  });

  it('formatResult uses engineering notation for very small values', () => {
    const out = formatResult({
      value: 0.000003421,
      unit: 'N',
      label: 'Force',
      significantFigures: 4,
    });
    expect(out.unit).toBe('µN');
  });

  it('formatResult uses kN for large force values', () => {
    const out = formatResult({
      value: 144.3456789,
      unit: 'N',
      label: 'Force',
      significantFigures: 10,
    });
    expect(out.value).toBe('144.34568');
  });

  it('MAX_DECIMALS is 5', () => {
    expect(MAX_DECIMALS).toBe(5);
  });

  it('formatTick never exceeds 5 decimal places', () => {
    // Import is not available in test; test via formatResult instead
    const out = formatResult({
      value: 0.373492847,
      unit: '-',
      significantFigures: 10,
    });
    const decimalPlaces = out.value.includes('.') ? out.value.split('.')[1].length : 0;
    expect(decimalPlaces).toBeLessThanOrEqual(5);
  });

  it('formatResult preserves negative signs', () => {
    const out = formatResult({
      value: -14.5678,
      unit: '-',
      label: 'Change',
      significantFigures: 6,
    });
    expect(out.value).toBe('-14.5678');
  });

  it('formatResult uses thousands separators for large values', () => {
    const out = formatResult({
      value: 1234567,
      unit: 'N',
      label: 'Force',
      significantFigures: 7,
    });
    expect(out.unit).toBe('MN');
  });

  it('formatResult fullText includes unit once without duplication', () => {
    const out = formatResult({
      value: 50,
      unit: 'N',
      label: 'Lift',
      showUnit: true,
      showLabel: true,
    });
    expect(out.fullText).toBe('Lift: 50 [N]');
    expect(out.displayText).toBe('Lift: 50 [N]');
  });
});

describe('axis formatting', () => {
  it('tick formatting stays within 5 decimal places for small values', () => {
    const out = formatResult({
      value: 0.123456789,
      unit: '-',
      significantFigures: 10,
    });
    const decimalPlaces = out.value.includes('.') ? out.value.split('.')[1].length : 0;
    expect(decimalPlaces).toBeLessThanOrEqual(5);
  });

  it('tick formatting uses SI prefixes for large values', () => {
    const out = formatResult({
      value: 686500,
      unit: 'N',
      significantFigures: 4,
    });
    expect(out.unit).toBe('kN');
    expect(out.value).toBe('686.5');
  });
});

describe('formatNumber', () => {
  it('removes floating-point representation artifacts', () => {
    expect(formatNumber(0.027330000000000004)).toBe('0.02733');
    expect(formatNumber(14.950000000000001)).toBe('14.95');
    expect(formatNumber(2.2800000000000002)).toBe('2.28');
    expect(formatNumber(0.40860000000000002)).toBe('0.4086');
  });

  it('groups thousands for large values', () => {
    expect(formatNumber(73500.00000000001, { thousands: true, engineering: false })).toBe('73,500');
  });

  it('trims trailing zeros', () => {
    expect(formatNumber(0.8)).toBe('0.8');
    expect(formatNumber(10)).toBe('10');
  });

  it('uses SI-prefix notation for very small values', () => {
    expect(formatNumber(0.000000123456789, { engineering: true })).toBe('123.5n');
    expect(formatNumber(0.000123456789, { engineering: true })).toBe('123.5µ');
  });

  it('caps decimal places at MAX_DECIMALS', () => {
    const out = formatNumber(0.373492847, { sigFigs: 10 });
    const decimals = out.includes('.') ? out.split('.')[1].length : 0;
    expect(decimals).toBeLessThanOrEqual(5);
  });

  it('returns em dash for non-finite values', () => {
    expect(formatNumber(NaN)).toBe('—');
    expect(formatNumber(Infinity)).toBe('—');
    expect(formatNumber(-Infinity)).toBe('—');
  });

  it('preserves negative sign', () => {
    expect(formatNumber(-14.5678)).toBe('-14.57');
    expect(formatNumber(-0.02733)).toBe('-0.02733');
  });
});

describe('plot configuration validation', () => {
  it('all four BWB plot presets resolve', () => {
    expect(getPlotDefinition('aircraft.dragPolar')).toBeDefined();
    expect(getPlotDefinition('aircraft.ldVsSpeed')).toBeDefined();
    expect(getPlotDefinition('aircraft.thrustVsSpeed')).toBeDefined();
    expect(getPlotDefinition('aircraft.ldVsMassPenalty')).toBeDefined();
  });

  it('drag polar uses dragPolarModel (not aircraftPerformanceModel)', () => {
    const def = getPlotDefinition('aircraft.dragPolar');
    expect(def?.modelId).toBe(dragPolarModel.id);
  });

  it('drag polar sweeps CL from 0.1 to 2.0', () => {
    const def = getPlotDefinition('aircraft.dragPolar');
    expect(def?.sweepParam).toBe('cl');
    expect(def?.xRange).toEqual([0.1, 2.0]);
  });

  it('thrust plot sweeps velocity from 40 to 200 m/s', () => {
    const def = getPlotDefinition('aircraft.thrustVsSpeed');
    expect(def?.sweepParam).toBe('velocity');
    expect(def?.xRange).toEqual([40, 200]);
  });
});

describe('rehypeEngineeringAnnotations', () => {
  it('wraps multiple percentage values in table cells without regex statefulness skipping', () => {
    const plugin = rehypeEngineeringAnnotations();
    const mockTree: any = {
      type: 'root',
      children: [
        {
          type: 'element',
          tagName: 'td',
          children: [
            { type: 'text', value: 'Delta (+15.1%) and (-8.4%) followed by (±2.0%)' },
          ],
        },
      ],
    };

    plugin(mockTree);

    const cell = mockTree.children[0];
    const spans = cell.children.filter((c: any) => c.type === 'element' && c.tagName === 'span');
    expect(spans).toHaveLength(3);
    expect(spans[0].children[0].value).toBe('(+15.1%)');
    expect(spans[1].children[0].value).toBe('(-8.4%)');
    expect(spans[2].children[0].value).toBe('(±2.0%)');
  });
});


