// Interactive scientific plot built on uPlot, loaded lazily only when the
// component mounts. uPlot has no eval/new-Function dependency, so it works
// under strict CSP. All calculations remain in the model layer; this
// component only renders.
//
// Lifecycle rules:
// - All React hooks run unconditionally, before any early return (fixes the
//   hook-order / minified React #310 crash).
// - The chart instance is created in a structural effect and destroyed in its
//   cleanup, so mounts, updates, unmounts and remounts are safe.
// - Style-only changes (grid, markers, line width, series visibility, axis
//   limits) are applied live to the existing instance via applySettings.
// - Structural changes (series, axes, scale type, precision, theme) destroy
//   and recreate the chart.
// - Every DOM event listener is tracked and removed in cleanup.
import { useCallback, useEffect, useRef, useState, useId } from 'react';
import type uPlot from 'uplot';
import type { EngineeringPlotConfig, PlotSeries } from '../../../lib/engineering/types';
import { axisExtent, panRange, zoomRange } from '../../../lib/engineering/plotScales';
import { isFiniteNumber } from '../../../lib/engineering/validation';
import { formatNumber } from '../../../lib/engineering/format';
import { EngineeringPointInspector } from '../shared/EngineeringPointInspector';
import { renderMathText } from '../../../lib/engineering/formatMath';
import { ZoomIcon, PanIcon, ResetIcon, SettingsIcon, DownloadIcon, CrosshairIcon } from './PlotIcons';

type InteractionMode = 'inspect' | 'zoom' | 'pan';
type Precision = 3 | 4 | 5 | 6;

const PRECISION_LABELS: Record<Precision, string> = { 3: '3 sig figs', 4: '4 sig figs', 5: '5 sig figs', 6: '6 sig figs' };

// uPlot scale distribution constants (uPlot declares these as a const enum,
// which is awkward to import under isolatedModules).
const DISTR_LINEAR = 1;
const DISTR_LOGARITHMIC = 3;

interface InspectionPoint {
  x: number;
  y: number;
  seriesIndex: number;
  seriesLabel: string;
  xText?: string;
  yText?: string;
}

interface InspectionState {
  primary: InspectionPoint | null;
  comparison: InspectionPoint | null;
}

interface ReadoutSeries {
  label: string;
  value: string;
  color: string;
}

interface ReadoutState {
  x: string;
  series: ReadoutSeries[];
}

interface EngineeringPlotProps {
  config: EngineeringPlotConfig;
  className?: string;
  height?: number;
  toolbar?: 'floating' | 'compact' | 'minimal' | 'none';
  onPointSelect?: (x: number, y: number, seriesIndex: number, kind: 'primary' | 'comparison') => void;
  inspectable?: boolean;
  inspectorSeriesIndex?: number;
  inspectorMetrics?: Array<{ id: string; label: string; unit?: string; significantFigures?: number }>;
  inspectorMetricValues?: Record<string, number>;
  inspectorComparisonValues?: Record<string, number>;
}

type PlotInstance = InstanceType<typeof uPlot>;

function readTheme(): 'dark' | 'light' {
  if (typeof document === 'undefined') return 'light';
  return document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light';
}

function themeText(theme: 'dark' | 'light'): string {
  return theme === 'dark' ? '#ECEAE4' : '#22211D';
}

function themeGrid(theme: 'dark' | 'light'): string {
  return theme === 'dark' ? '#2B2A26' : '#E2DFD6';
}

function themeAccent(theme: 'dark' | 'light'): string {
  return theme === 'dark' ? '#E25835' : '#BA3D18';
}

/** Convert a hex, rgb, or rgba string to an rgba string with a specified alpha. */
function colorWithAlpha(color: string, alpha: number): string {
  if (!color) return `rgba(255, 96, 59, ${alpha})`;
  if (color.startsWith('#')) {
    let hex = color.slice(1);
    if (hex.length === 3) {
      hex = hex.split('').map((c) => c + c).join('');
    }
    if (hex.length >= 6) {
      const r = parseInt(hex.slice(0, 2), 16);
      const g = parseInt(hex.slice(2, 4), 16);
      const b = parseInt(hex.slice(4, 6), 16);
      return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
  } else if (color.startsWith('rgb(')) {
    const parts = color.slice(4, -1).split(',').map((p) => p.trim());
    if (parts.length >= 3) {
      return `rgba(${parts[0]}, ${parts[1]}, ${parts[2]}, ${alpha})`;
    }
  } else if (color.startsWith('rgba(')) {
    const parts = color.slice(5, -1).split(',').map((p) => p.trim());
    if (parts.length >= 3) {
      return `rgba(${parts[0]}, ${parts[1]}, ${parts[2]}, ${alpha})`;
    }
  }
  return color;
}

/** Format a value for an axis tick or cursor readout.
 *  Never exceeds 5 decimal places; trailing zeros are trimmed. */
function formatAxisValue(val: number, unit: string | undefined, sigFigs: number): string {
  if (!isFiniteNumber(val)) return '—';
  if (val === 0) return unit && unit !== '-' ? `0 [${unit}]` : '0';
  const numStr = formatNumber(val, { sigFigs, thousands: true });
  return unit && unit !== '-' ? `${numStr} [${unit}]` : numStr;
}

/** Format a tick label for an axis (no unit suffix). */
function formatTick(val: number, sigFigs: number): string {
  if (!Number.isFinite(val)) return '';
  if (val === 0) return '0';
  return formatNumber(val, { sigFigs, thousands: true });
}

/** Estimate text width using canvas font metrics. */
function measureTextWidth(text: string, fontSize: number): number {
  if (typeof document === 'undefined') return text.length * fontSize * 0.6;
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) return text.length * fontSize * 0.6;
  ctx.font = `${fontSize}px ${getComputedStyle(document.documentElement).fontFamily || 'system-ui'}`;
  return ctx.measureText(text).width;
}

/** Compute the [min, max] extent of X and all finite Y values across series.
 *  Used as the autoscale target so both axes fit the data (uPlot only
 *  autoscales X on construction). */
function computeDataExtent(series: PlotSeries[], xType: 'linear' | 'log' = 'linear', yType: 'linear' | 'log' = 'linear'): { x: [number, number]; y: [number, number] } {
  return { x: axisExtent(series[0]?.x ?? [], xType), y: axisExtent(series.flatMap(s => s.y), yType) };
}

/** Set both X and Y scales to the data extent (true autoscale).
 *  uPlot only autoscales X on construction / setData, so Y must be set
 *  explicitly here. */
function applyAutoscale(inst: PlotInstance, series: PlotSeries[], xType: 'linear' | 'log', yType: 'linear' | 'log'): void {
  if (!inst || !inst.setScale) return;
  const { x: dataX, y: dataY } = computeDataExtent(series, xType, yType);
  inst.setScale('x', { min: dataX[0], max: dataX[1] });
  inst.setScale('y', { min: dataY[0], max: dataY[1] });
}

export function EngineeringPlot({
  config,
  className,
  height = 400,
  toolbar = 'floating',
  onPointSelect,
  inspectable = false,
  inspectorSeriesIndex = 0,
  inspectorMetrics = [],
  inspectorMetricValues = {},
  inspectorComparisonValues = {},
}: EngineeringPlotProps) {
  // -----------------------------------------------------------------------
  // Refs (all created unconditionally at the top of the render).
  // -----------------------------------------------------------------------
  const uPlotConstructorRef = useRef<typeof uPlot | null>(null);
  const chartInstanceRef = useRef<PlotInstance | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const chartStructureRef = useRef<string | null>(null);
  const configRef = useRef<EngineeringPlotConfig>(config);
  const listenersRef = useRef<Array<() => void>>([]);
  const themeRef = useRef(readTheme());

  // Axes size refs for dynamic measurement.
  const xAxisSizeRef = useRef(24);
  const yAxisSizeRef = useRef(48);

  // Pan / touch state.
  const panStateRef = useRef<{
    dragging: boolean;
    moved: boolean;
    startX: number;
    startY: number;
    startXMin: number;
    startXMax: number;
    startYMin: number;
    startYMax: number;
  } | null>(null);
  const lastHoverIdxRef = useRef<number | null>(null);

  // -----------------------------------------------------------------------
  // State (all hooks unconditional, before any early return).
  // -----------------------------------------------------------------------
  const [loaded, setLoaded] = useState(false);
  const [loadAttempt, setLoadAttempt] = useState(0);
  const [loadError, setLoadError] = useState<Error | null>(null);
  const [initError, setInitError] = useState<Error | null>(null);
  const [theme, setTheme] = useState<'dark' | 'light'>(readTheme);

  // Sync theme changes from html[data-theme]
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const updateTheme = () => {
      const current = readTheme();
      setTheme(current);
      themeRef.current = current;
    };
    updateTheme();
    if (typeof MutationObserver === 'undefined') return;
    const observer = new MutationObserver(() => updateTheme());
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['data-theme'],
    });
    return () => observer.disconnect();
  }, []);

  const [inspection, setInspection] = useState<InspectionState>({ primary: null, comparison: null });
  const [showSettings, setShowSettings] = useState(false);
  const [showGrid, setShowGrid] = useState(true);
  const [yScaleType, setYScaleType] = useState<'linear' | 'log'>(config.yAxis.type ?? 'linear');
  const xScaleType = config.xAxis.type ?? 'linear';
  useEffect(() => { setYScaleType(config.yAxis.type ?? 'linear'); setYMin(config.yAxis.range?.[0] ?? null); setYMax(config.yAxis.range?.[1] ?? null); }, [config.yAxis.type, config.yAxis.range?.[0], config.yAxis.range?.[1]]);
  useEffect(() => { setXMin(config.xAxis.range?.[0] ?? null); setXMax(config.xAxis.range?.[1] ?? null); }, [config.xAxis.type, config.xAxis.range?.[0], config.xAxis.range?.[1]]);
  const [xMin, setXMin] = useState<number | null>(config.xAxis.range?.[0] ?? null);
  const [xMax, setXMax] = useState<number | null>(config.xAxis.range?.[1] ?? null);
  const [yMin, setYMin] = useState<number | null>(config.yAxis.range?.[0] ?? null);
  const [yMax, setYMax] = useState<number | null>(config.yAxis.range?.[1] ?? null);
  const [showMarkers, setShowMarkers] = useState(config.series.some(s => s.mode === 'lines+markers'));
  const [lineWidth, setLineWidth] = useState(2);
  const [showLegend, setShowLegend] = useState(config.legend !== false);
  const [enableGlow, setEnableGlow] = useState(true);
  const [showAreaShading, setShowAreaShading] = useState(true);
  const [interactionMode, setInteractionMode] = useState<InteractionMode>('inspect');
  const [seriesVisibility, setSeriesVisibility] = useState<Record<string, boolean>>({});
  const [sigFigs, setSigFigs] = useState<Precision>(4);
  const [cursorReadoutEnabled, setCursorReadoutEnabled] = useState(config.tooltips !== false);
  const [hoverReadout, setHoverReadout] = useState<ReadoutState | null>(null);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const exportMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!showExportMenu) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (exportMenuRef.current && !exportMenuRef.current.contains(e.target as Node)) {
        setShowExportMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showExportMenu]);

  // Bumps whenever the series data reference changes so the chart re-renders
  // new data on the existing instance (no destruction/recreation).
  const [dataVersion, setDataVersion] = useState(0);
  useEffect(() => {
    setDataVersion((version) => version + 1);
  }, [config.series]);

  // settingsPanelId must come before any conditional return.
  const settingsPanelId = useId().replace(/:/g, '-');

  // Keep the latest config in a ref so style effects never depend on prop
  // identity (callers may pass inline objects).
  configRef.current = config;

  const tooltipsEnabled = cursorReadoutEnabled && config.tooltips !== false;

  // -----------------------------------------------------------------------
  // Derived data validation.
  // -----------------------------------------------------------------------
  const validateData = useCallback(
    (series: PlotSeries[]): { valid: boolean; data: uPlot.AlignedData; error: string | null } => {
      if (!series.length) {
        return { valid: false, data: [], error: 'No data series configured.' };
      }

      const x = series[0].x;
      if (!x.length) {
        return { valid: false, data: [], error: 'No X data points.' };
      }

      for (const s of series) {
        if (!s.x || s.x.length !== x.length) {
          return { valid: false, data: [], error: `X coordinate mismatch for series "${s.label}".` };
        }
        for (let i = 0; i < x.length; i++) {
          if (s.x[i] !== x[i]) {
            return { valid: false, data: [], error: `X coordinate mismatch for series "${s.label}".` };
          }
        }
      }

      if (x.some((value, index) => !isFiniteNumber(value) || (index > 0 && value <= x[index - 1]))) {
        return { valid: false, data: [], error: 'X values must be finite and strictly increasing.' };
      }
      if (xScaleType === 'log' && x.some(value => value <= 0)) return { valid: false, data: [], error: 'Logarithmic X axes require positive values.' };
      if (yScaleType === 'log' && series.some(s => s.y.some(value => isFiniteNumber(value) && value <= 0))) return { valid: false, data: [], error: 'Logarithmic Y axes require positive values.' };
      if (series.some(s => s.y.length !== x.length)) return { valid: false, data: [], error: 'Each series must have one Y value per X value.' };
      const data = [x, ...series.map(s => s.y.map(value => isFiniteNumber(value) ? value : null))] as uPlot.AlignedData;

      return { valid: true, data, error: null };
    },
    [xScaleType, yScaleType],
  );

  // -----------------------------------------------------------------------
  // Structural key: changes destroy and recreate the chart instance.
  // Style-only settings live in applySettings and do not recreate.
  // -----------------------------------------------------------------------
  const getStructureKey = useCallback((): string => {
    return JSON.stringify({
      xAxis: config.xAxis,
      yAxis: config.yAxis,
      series: config.series.map((s) => ({ id: s.id, label: s.label, mode: s.mode, color: s.color, fill: s.fill })),
      scaleX: config.xAxis.range,
      scaleY: config.yAxis.range,
      distr: [xScaleType, yScaleType],
      showLegend,
      sigFigs,
      theme,
      interactionMode,
      showGrid,
      showMarkers,
      lineWidth,
      enableGlow,
      showAreaShading,
      shadedRegions: config.shadedRegions,
      referenceLines: config.referenceLines,
    });
  }, [
    config.xAxis,
    config.yAxis,
    config.series,
    config.shadedRegions,
    config.referenceLines,
    xScaleType,
    yScaleType,
    showLegend,
    sigFigs,
    theme,
    interactionMode,
    showGrid,
    showMarkers,
    lineWidth,
    enableGlow,
    showAreaShading,
  ]);

  const buildSeries = useCallback((): any[] => {
    const series: any[] = [{}];
    const theme = themeRef.current;
    for (const s of configRef.current.series) {
      const visible = seriesVisibility[s.id] ?? (s.visible !== false);
      const strokeColor = s.color || themeAccent(theme);
      // Area fill: enabled if showAreaShading is true and (fill is explicitly true/string, or fill is undefined on a line series)
      const isLineMode = (s.mode ?? 'lines').includes('lines');
      const hasFill = showAreaShading && s.fill !== false && (s.fill === true || typeof s.fill === 'string' || (s.fill === undefined && isLineMode));

      let fillValue: any = undefined;
      if (hasFill) {
        if (typeof s.fill === 'string') {
          fillValue = s.fill;
        } else {
          // Luminous vertical gradient
          fillValue = (u: PlotInstance) => {
            const ctx = u.ctx;
            const bbox = u.bbox;
            const fallback = colorWithAlpha(strokeColor, theme === 'dark' ? 0.14 : 0.08);
            if (
              !ctx ||
              !bbox ||
              typeof ctx.createLinearGradient !== 'function' ||
              !Number.isFinite(bbox.top) ||
              !Number.isFinite(bbox.height) ||
              bbox.height <= 0
            ) {
              return fallback;
            }
            try {
              const grad = ctx.createLinearGradient(0, bbox.top, 0, bbox.top + bbox.height);
              const topAlpha = theme === 'dark' ? 0.22 : 0.14;
              const midAlpha = theme === 'dark' ? 0.07 : 0.04;
              grad.addColorStop(0, colorWithAlpha(strokeColor, topAlpha));
              grad.addColorStop(0.55, colorWithAlpha(strokeColor, midAlpha));
              grad.addColorStop(1, colorWithAlpha(strokeColor, 0));
              return grad;
            } catch {
              return fallback;
            }
          };
        }
      }

      series.push({
        label: s.label,
        stroke: strokeColor,
        fill: s.mode === 'markers' ? undefined : fillValue,
        width: s.mode === 'markers' ? 0 : lineWidth,
        points: {
          show: s.mode === 'markers' || showMarkers,
          size: 5,
          width: 1.5,
          stroke: '#ffffff',
          fill: strokeColor,
        },
        spanGaps: true,
        show: visible,
      });
    }
    return series;
  }, [seriesVisibility, lineWidth, showMarkers, showAreaShading]);

  const buildAxes = useCallback((): any[] => {
    const theme = themeRef.current;
    const cleanMath = (s: string) => s.replace(/\$([^\$]+)\$/g, '$1');
    const xUnit = config.xAxis.unit && config.xAxis.unit !== '-' ? ` (${cleanMath(config.xAxis.unit)})` : '';
    const yUnit = config.yAxis.unit && config.yAxis.unit !== '-' ? ` (${cleanMath(config.yAxis.unit)})` : '';
    const xTitle = `${cleanMath(config.xAxis.title)}${xUnit}`;
    const yTitle = `${cleanMath(config.yAxis.title)}${yUnit}`;

    const xAxisSize = Math.max(24, measureTextWidth(xTitle, 12) * 0.5 + 14);
    const yAxisSize = Math.max(48, measureTextWidth(yTitle, 12) * 0.5 + 14);
    xAxisSizeRef.current = xAxisSize;
    yAxisSizeRef.current = yAxisSize;

    const gridStroke = showGrid ? themeGrid(theme) : 'transparent';

    return [
      {
        show: true,
        stroke: themeText(theme),
        grid: { stroke: gridStroke, width: 1 },
        ticks: { stroke: gridStroke, width: 1 },
        size: xAxisSize,
        label: xTitle,
        labelSize: 14,
        labelFont: '12px system-ui, sans-serif',
        font: '11px system-ui, sans-serif',
        values: (_u: any, vals: number[]) => vals.map((v) => formatTick(v, sigFigs)),
      },
      {
        show: true,
        stroke: themeText(theme),
        grid: { stroke: gridStroke, width: 1 },
        ticks: { stroke: gridStroke, width: 1 },
        size: yAxisSize,
        label: yTitle,
        labelSize: 14,
        labelFont: '12px system-ui, sans-serif',
        font: '11px system-ui, sans-serif',
        values: (_u: any, vals: number[]) => vals.map((v) => formatTick(v, sigFigs)),
      },
    ];
  }, [config.xAxis, config.yAxis, sigFigs, showGrid]);

  // Apply style-only settings to an existing chart instance without recreating it.
  const applySettings = useCallback((inst: PlotInstance) => {
    if (!inst) return;
    try {
      const cfg = configRef.current;

      cfg.series.forEach((series, index) => {
        const visible = seriesVisibility[series.id] ?? (series.visible !== false);
        inst.setSeries(index + 1, { show: visible });
      });

      if (inst.scales) {
        const xScale = inst.scales.x;
        const yScale = inst.scales.y;
        if (xScale && (xMin != null || xMax != null) && (xScaleType !== 'log' || [xMin, xMax].every(v => v == null || v > 0))) {
          inst.setScale('x', { min: xMin ?? xScale.min ?? 0, max: xMax ?? xScale.max ?? 0 });
        }
        if (yScale && (yMin != null || yMax != null) && (yScaleType !== 'log' || [yMin, yMax].every(v => v == null || v > 0))) {
          inst.setScale('y', { min: yMin ?? yScale.min ?? 0, max: yMax ?? yScale.max ?? 0 });
        }
      }
    } catch (e) {
      console.warn('[EngineeringPlot] applySettings partial failure:', e);
    }
  }, [config.series, seriesVisibility, xMin, xMax, yMin, yMax, xScaleType, yScaleType]);

  const initChart = useCallback(() => {
    const uPlot = uPlotConstructorRef.current;
    const container = containerRef.current;
    if (!uPlot || !container) return;

    const validation = validateData(config.series);
    if (!validation.valid) {
      setInitError(new Error(validation.error ?? 'Unknown plot error.'));
      return;
    }
    setInitError(null);

    const width = container.clientWidth;
    if (width <= 0) {
      // Container hasn't laid out yet (common during Astro hydration).
      // ResizeObserver will initialize once this container has a positive width.
      return;
    }

    if ((xScaleType === 'log' && [xMin, xMax].some(value => value != null && value <= 0)) || (yScaleType === 'log' && [yMin, yMax].some(value => value != null && value <= 0))) {
      setInitError(new Error('Logarithmic axis bounds must be positive.'));
      return;
    }
    const inst = chartInstanceRef.current;
    const structureKey = getStructureKey();

    // Same structure: update data on the existing instance.
    if (inst && inst.setData && chartStructureRef.current === structureKey) {
      try {
        inst.setData(validation.data as unknown as uPlot.AlignedData, false);
        applySettings(inst);
        chartStructureRef.current = structureKey;
        return;
      } catch {
        // Fall through to full reinitialization below.
      }
    }

    // Different structure (or no instance): destroy and recreate.
    if (inst && inst.destroy) {
      inst.destroy();
    }

    const theme = themeRef.current;

    // Autoscale both axes to the data by default (uPlot only autoscales X on
    // construction). Manual axis bounds from settings override autoscale.
    const { x: dataX, y: dataY } = computeDataExtent(config.series, xScaleType, yScaleType);

    const opts: any = {
      width,
      height,
      plugins: [],
      series: buildSeries(),
      axes: buildAxes(),
      scales: {
        x: {
          time: false,
          distr: xScaleType === 'log' ? DISTR_LOGARITHMIC : DISTR_LINEAR,
          min: xMin ?? dataX[0],
          max: xMax ?? dataX[1],
        },
        y: {
          distr: yScaleType === 'log' ? DISTR_LOGARITHMIC : DISTR_LINEAR,
          min: yMin ?? dataY[0],
          max: yMax ?? dataY[1],
        },
      },
      cursor: {
        show: tooltipsEnabled,
        x: true,
        y: true,
        lock: true,
        points: { show: true, size: 6, stroke: '#ffffff', width: 1.5 },
        drag: {
          setScale: false,
          x: interactionMode === 'zoom',
          y: interactionMode === 'zoom',
        },
      },
      legend: {
        show: showLegend,
        live: false,
        markers: {
          show: true,
          fill: (_u: any, si: number) => {
            const spec = configRef.current.series[si - 1];
            return spec?.color || themeAccent(themeRef.current);
          },
          stroke: (_u: any, si: number) => {
            const spec = configRef.current.series[si - 1];
            return spec?.color || themeAccent(themeRef.current);
          },
        },
      },
      select:
        interactionMode === 'zoom'
          ? {
              show: true,
              marginLeft: yAxisSizeRef.current,
              marginTop: 0,
              marginRight: 20,
              marginBottom: xAxisSizeRef.current,
              stroke: '#ff603b80',
              fill: '#ff603b20',
              cursor: 'crosshair',
            }
          : false,
      hooks: {
        setSelect: [
          (u: PlotInstance) => {
            if (interactionMode !== 'zoom') return;
            const sel = u.select;
            if (!sel || sel.width < 8) return;
            const minX = u.posToVal(sel.left, 'x');
            const maxX = u.posToVal(sel.left + sel.width, 'x');
            if (Number.isFinite(minX) && Number.isFinite(maxX) && minX !== maxX) {
              const newMin = Math.min(minX, maxX);
              const newMax = Math.max(minX, maxX);
              setXMin(newMin);
              setXMax(newMax);
              u.setScale('x', { min: newMin, max: newMax });
            }
            if (sel.height >= 8) {
              const valY1 = u.posToVal(sel.top, 'y');
              const valY2 = u.posToVal(sel.top + sel.height, 'y');
              if (Number.isFinite(valY1) && Number.isFinite(valY2) && valY1 !== valY2) {
                const newYMin = Math.min(valY1, valY2);
                const newYMax = Math.max(valY1, valY2);
                setYMin(newYMin);
                setYMax(newYMax);
                u.setScale('y', { min: newYMin, max: newYMax });
              }
            }
            u.setSelect({ left: 0, top: 0, width: 0, height: 0 }, false);
          },
        ],
        setCursor: [
          (u: PlotInstance) => {
            if (!tooltipsEnabled) return;
            const idx = u.cursor?.idx;
            if (idx == null || idx < 0) {
              if (lastHoverIdxRef.current !== null) {
                setHoverReadout(null);
                lastHoverIdxRef.current = null;
              }
              return;
            }
            if (idx === lastHoverIdxRef.current) return;
            lastHoverIdxRef.current = idx;

            const data = u.data;
            if (!data) return;
            const xVal = data[0][idx];
            if (!isFiniteNumber(xVal)) {
              setHoverReadout(null);
              return;
            }

            const series = config.series;
            const entries: ReadoutSeries[] = [];
            for (let s = 1; s < data.length; s++) {
              const spec = series[s - 1];
              if (!spec) continue;
              if (seriesVisibility[spec.id] === false) continue;
              const yVal = data[s][idx];
              if (!isFiniteNumber(yVal)) continue;
              entries.push({
                label: spec.label,
                value: formatAxisValue(yVal, config.yAxis.unit, sigFigs),
                color: spec.color || themeAccent(theme),
              });
            }

            if (entries.length === 0) {
              setHoverReadout(null);
              return;
            }

            setHoverReadout({
              x: formatAxisValue(xVal, config.xAxis.unit, sigFigs),
              series: entries,
            });
          },
        ],
        drawClear: [
          (u: PlotInstance) => {
            const shaded = configRef.current.shadedRegions;
            if (!shaded || shaded.length === 0) return;
            const ctx = u.ctx;
            if (!ctx || typeof ctx.save !== 'function') return;
            const bbox = u.bbox;
            if (!bbox) return;
            const { left, top, width, height } = bbox;

            ctx.save();
            ctx.beginPath();
            ctx.rect(left, top, width, height);
            ctx.clip();

            for (const region of shaded) {
              const minXVal = region.x0 ?? region.xRange?.[0];
              const maxXVal = region.x1 ?? region.xRange?.[1];
              const minYVal = region.y0 ?? region.yRange?.[0];
              const maxYVal = region.y1 ?? region.yRange?.[1];

              // u.valToPos(val, scale, true) returns physical canvas coordinates directly
              const px0 = minXVal != null ? u.valToPos(minXVal, 'x', true) : left;
              const px1 = maxXVal != null ? u.valToPos(maxXVal, 'x', true) : left + width;
              const py0 = minYVal != null ? u.valToPos(minYVal, 'y', true) : top + height;
              const py1 = maxYVal != null ? u.valToPos(maxYVal, 'y', true) : top;

              const rLeft = Math.min(px0, px1);
              const rRight = Math.max(px0, px1);
              const rTop = Math.min(py0, py1);
              const rBottom = Math.max(py0, py1);

              const baseColor = region.color || 'rgba(255, 96, 59, 0.10)';
              ctx.fillStyle = baseColor;
              ctx.fillRect(rLeft, rTop, rRight - rLeft, rBottom - rTop);

              // Subtle glowing edge border for shaded region
              ctx.strokeStyle = colorWithAlpha(baseColor, 0.35);
              ctx.lineWidth = 1;
              ctx.strokeRect(rLeft, rTop, rRight - rLeft, rBottom - rTop);

              if (region.label) {
                ctx.save();
                ctx.font = '10px var(--mono, monospace)';
                ctx.fillStyle = 'var(--muted, #888888)';
                ctx.textAlign = 'left';
                ctx.textBaseline = 'top';
                ctx.fillText(region.label, rLeft + 6, rTop + 6);
                ctx.restore();
              }
            }
            ctx.restore();
          },
        ],
        draw: [
          (u: PlotInstance) => {
            const ctx = u.ctx;
            if (!ctx || typeof ctx.save !== 'function') return;
            const bbox = u.bbox;
            if (!bbox) return;
            const { left, top, width, height } = bbox;
            const theme = themeRef.current;

            // 1. Radiant Series Bloom / Glow Pass
            if (enableGlow && typeof ctx.stroke === 'function') {
              ctx.save();
              ctx.beginPath();
              ctx.rect(left, top, width, height);
              ctx.clip();

              const dpr = typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1;

              for (let i = 1; i < u.series.length; i++) {
                const s = u.series[i];
                const spec = configRef.current.series[i - 1];
                if (!s || !s.show || !spec) continue;
                const strokePath = (s as any)._paths?.stroke;
                if (!strokePath) continue;

                const strokeColor = spec.color || themeAccent(theme);
                const glowBlur = (theme === 'dark' ? 10 : 5) * dpr;
                const glowAlpha = theme === 'dark' ? 0.6 : 0.3;

                ctx.save();
                ctx.shadowColor = colorWithAlpha(strokeColor, glowAlpha);
                ctx.shadowBlur = glowBlur;
                ctx.strokeStyle = colorWithAlpha(strokeColor, theme === 'dark' ? 0.4 : 0.25);
                ctx.lineWidth = (s.width || lineWidth) + 1.5 * dpr;
                ctx.stroke(strokePath);
                ctx.restore();
              }
              ctx.restore();
            }

            // 2. Reference Lines with corrected coordinates & subtle bloom
            const refLines = configRef.current.referenceLines;
            if (refLines && refLines.length > 0) {
              ctx.save();
              ctx.beginPath();
              ctx.rect(left, top, width, height);
              ctx.clip();

              for (const ref of refLines) {
                const strokeColor = ref.color || 'var(--accent, #ff603b)';
                ctx.save();
                if (enableGlow) {
                  ctx.shadowColor = colorWithAlpha(strokeColor, 0.45);
                  ctx.shadowBlur = 4;
                }
                ctx.beginPath();
                ctx.strokeStyle = strokeColor;
                ctx.lineWidth = 1.5;
                if (typeof ctx.setLineDash === 'function') {
                  if (ref.dash === 'dot') ctx.setLineDash([2, 2]);
                  else if (ref.dash === 'dashdot') ctx.setLineDash([6, 3, 2, 3]);
                  else ctx.setLineDash([4, 4]);
                }

                if (ref.axis === 'x') {
                  const x = u.valToPos(ref.value, 'x', true);
                  ctx.moveTo(x, top);
                  ctx.lineTo(x, top + height);
                  ctx.stroke();
                  if (typeof ctx.setLineDash === 'function') ctx.setLineDash([]);

                  if (ref.label) {
                    ctx.font = '10px var(--mono, monospace)';
                    ctx.fillStyle = strokeColor;
                    ctx.textAlign = 'left';
                    ctx.textBaseline = 'top';
                    ctx.fillText(ref.label, x + 4, top + 6);
                  }
                } else {
                  const y = u.valToPos(ref.value, 'y', true);
                  ctx.moveTo(left, y);
                  ctx.lineTo(left + width, y);
                  ctx.stroke();
                  if (typeof ctx.setLineDash === 'function') ctx.setLineDash([]);

                  if (ref.label) {
                    ctx.font = '10px var(--mono, monospace)';
                    ctx.fillStyle = strokeColor;
                    ctx.textAlign = 'left';
                    ctx.textBaseline = 'bottom';
                    ctx.fillText(ref.label, left + 6, y - 4);
                  }
                }
                ctx.restore();
              }
              ctx.restore();
            }
          },
        ],
      },
    };

    try {
      const newInst = new uPlot(opts, validation.data as unknown as uPlot.AlignedData, container);
      chartInstanceRef.current = newInst;
      chartStructureRef.current = structureKey;
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Failed to initialize plot');
      console.error('[EngineeringPlot] uPlot construction failed:', err);
      setInitError(err);
    }
  }, [
    config,
    height,
    validateData,
    getStructureKey,
    applySettings,
    buildSeries,
    buildAxes,
    tooltipsEnabled,
    interactionMode,
    seriesVisibility,
    yScaleType,
    xMin,
    xMax,
    yMin,
    yMax,
    showMarkers,
    lineWidth,
    showLegend,
    enableGlow,
    showAreaShading,
  ]);

  // -----------------------------------------------------------------------
  // Effect 1: library loading (mount-only, stable).
  // -----------------------------------------------------------------------
  useEffect(() => {
    let cancelled = false;

    import('uplot')
      .then((module: any) => {
        if (cancelled) return;
        uPlotConstructorRef.current = module.default ?? module;
        setLoaded(true);
        setLoadError(null);
      })
      .catch((error: any) => {
        if (!cancelled) {
          const err = error instanceof Error ? error : new Error('Failed to load plot library');
          console.error('[EngineeringPlot] uPlot import failed:', err);
          setLoadError(err);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [loadAttempt]);

  const retryLoad = useCallback(() => {
    setLoadError(null);
    setLoadAttempt(value => value + 1);
  }, []);

  // -----------------------------------------------------------------------
  // Effect 2: chart creation / structural updates / data refresh.
  //
  // The previous instance is destroyed only when the structure actually
  // changes (initChart handles that); data-only updates are applied live.
  // The instance is destroyed on unmount by Effect 4.
  // -----------------------------------------------------------------------
  useEffect(() => {
    if (!loaded || !uPlotConstructorRef.current || !containerRef.current) return;
    initChart();
  }, [loaded, dataVersion, initChart]);

  // Destroy the chart instance on unmount so repeated mount/unmount cycles
  // never leak canvases, ResizeObservers or event listeners.
  useEffect(() => {
    return () => {
      const inst = chartInstanceRef.current;
      if (inst && inst.destroy) {
        inst.destroy();
        chartInstanceRef.current = null;
      }
    };
  }, []);

  // -----------------------------------------------------------------------
  // Effect 3: style-only updates (applied live, no recreation).
  // -----------------------------------------------------------------------
  useEffect(() => {
    const inst = chartInstanceRef.current;
    if (inst) applySettings(inst);
  }, [showGrid, lineWidth, showMarkers, seriesVisibility, xMin, xMax, yMin, yMax, applySettings]);

  // -----------------------------------------------------------------------
  // Effect 4: resize, input listeners, and teardown.
  // -----------------------------------------------------------------------
  const initChartRef = useRef(initChart);
  initChartRef.current = initChart;
  const resizeHeightRef = useRef(height);
  resizeHeightRef.current = height;
  const onResize = () => {
    const inst = chartInstanceRef.current;
    const box = containerRef.current;
    if (!box || box.clientWidth <= 0) return;
    if (!inst) { initChartRef.current(); return; }
    inst.setSize?.({ width: box.clientWidth, height: resizeHeightRef.current });
  };

  const handleContainerClick = useCallback(
    (event: MouseEvent) => {
      const inst = chartInstanceRef.current;
      const container = containerRef.current;
      if (!inst || !container || !inspectable || interactionMode === 'zoom') return;

      // If user was dragging/panning the plot, do not trigger point inspection
      if (panStateRef.current?.moved) {
        panStateRef.current.moved = false;
        return;
      }

      const rect = container.getBoundingClientRect();
      const plotLeft = inst.bbox?.left ?? 0;
      const plotTop = inst.bbox?.top ?? 0;
      const plotX = event.clientX - rect.left - plotLeft;
      const plotY = event.clientY - rect.top - plotTop;

      const xValue = inst.posToVal(plotX, 'x');
      if (!Number.isFinite(xValue)) return;

      const series = config.series;
      const xData = series[0]?.x;
      if (!xData?.length) return;

      let nearestIdx = -1;
      if (inst.cursor && typeof inst.cursor.idx === 'number' && inst.cursor.idx >= 0) {
        nearestIdx = inst.cursor.idx;
      } else {
        let minDist = Infinity;
        for (let i = 0; i < xData.length; i++) {
          if (!isFiniteNumber(xData[i])) continue;
          const dist = Math.abs(xData[i] - xValue);
          if (dist < minDist) {
            minDist = dist;
            nearestIdx = i;
          }
        }
      }

      if (nearestIdx < 0) return;

      // Among visible series at this x, pick the point nearest the click
      // in screen-Y space (click a curve to inspect that operating point).
      const yValue = Number.isFinite(plotY) ? inst.posToVal(plotY, 'y') : NaN;
      let bestSeries = inspectorSeriesIndex ?? 0;
      let bestDist = Infinity;
      for (let s = 0; s < series.length; s++) {
        const spec = series[s];
        if (seriesVisibility[spec.id] === false) continue;
        const y = spec.y?.[nearestIdx];
        if (!isFiniteNumber(y)) continue;
        const dist = Math.abs(y - yValue);
        if (dist < bestDist) {
          bestDist = dist;
          bestSeries = s;
        }
      }

      const spec = series[bestSeries];
      if (!spec || !isFiniteNumber(spec.y[nearestIdx])) return;

      const kind = event.shiftKey ? 'comparison' : 'primary';
      setInspection((prev) => {
        const next = { ...prev };
        const point: InspectionPoint = {
          x: xData[nearestIdx],
          y: spec.y[nearestIdx],
          seriesIndex: bestSeries,
          seriesLabel: spec.label ?? 'Series',
          xText: formatAxisValue(xData[nearestIdx], config.xAxis.unit, sigFigs),
          yText: formatAxisValue(spec.y[nearestIdx], config.yAxis.unit, sigFigs),
        };
        if (kind === 'comparison') next.comparison = point;
        else next.primary = point;
        return next;
      });
      onPointSelect?.(xData[nearestIdx], spec.y[nearestIdx], bestSeries, kind);
    },
    [inspectable, interactionMode, inspectorSeriesIndex, config.series, seriesVisibility, sigFigs, onPointSelect],
  );

  const handlePanDown = useCallback(
    (e: MouseEvent) => {
      if (e.button !== 0) return; // Only left-click
      if (interactionMode === 'zoom') return;
      const inst = chartInstanceRef.current;
      const xScale = inst?.scales?.x;
      const yScale = inst?.scales?.y;
      if (!inst || !xScale || xScale.min == null || xScale.max == null) return;
      panStateRef.current = {
        dragging: true,
        moved: false,
        startX: e.clientX,
        startY: e.clientY,
        startXMin: xScale.min,
        startXMax: xScale.max,
        startYMin: yScale?.min ?? 0,
        startYMax: yScale?.max ?? 0,
      };
    },
    [interactionMode],
  );

  const handlePanMove = useCallback(
    (e: MouseEvent) => {
      const state = panStateRef.current;
      const inst = chartInstanceRef.current;
      if (!state?.dragging || !inst) return;
      const dx = e.clientX - state.startX;
      const dy = e.clientY - state.startY;

      // Strict 4px threshold before initiating pan to protect clicks
      if (!state.moved) {
        if (Math.hypot(dx, dy) < 4) return;
        state.moved = true;
        if (containerRef.current) {
          containerRef.current.style.cursor = 'grabbing';
        }
      }

      const plotWidth = inst.bbox?.width ?? ((containerRef.current?.clientWidth ?? 600) - yAxisSizeRef.current);
      const plotHeight = inst.bbox?.height ?? (height - xAxisSizeRef.current);
      const [newXMin, newXMax] = panRange(state.startXMin, state.startXMax, -dx / plotWidth, xScaleType);
      setXMin(newXMin);
      setXMax(newXMax);
      inst.setScale('x', { min: newXMin, max: newXMax });

      {
        const [newYMin, newYMax] = panRange(state.startYMin, state.startYMax, dy / plotHeight, yScaleType);
        setYMin(newYMin);
        setYMax(newYMax);
        inst.setScale('y', { min: newYMin, max: newYMax });
      }
    },
    [height, xScaleType, yScaleType],
  );

  const handlePanUp = useCallback(() => {
    if (panStateRef.current) {
      panStateRef.current.dragging = false;
      if (containerRef.current) {
        containerRef.current.style.cursor = interactionMode === 'zoom' ? 'crosshair' : 'default';
      }
    }
  }, [interactionMode]);

  const handleTouchStart = useCallback(
    (e: TouchEvent) => {
      if (interactionMode === 'zoom') return;
      const inst = chartInstanceRef.current;
      const xScale = inst?.scales?.x;
      const yScale = inst?.scales?.y;
      if (!inst || !xScale || xScale.min == null || xScale.max == null) return;
      const touch = e.touches[0];
      panStateRef.current = {
        dragging: true,
        moved: false,
        startX: touch.clientX,
        startY: touch.clientY,
        startXMin: xScale.min,
        startXMax: xScale.max,
        startYMin: yScale?.min ?? 0,
        startYMax: yScale?.max ?? 0,
      };
    },
    [interactionMode],
  );

  const handleTouchMove = useCallback(
    (e: TouchEvent) => {
      const state = panStateRef.current;
      const inst = chartInstanceRef.current;
      if (!state?.dragging || !inst) return;
      const touch = e.touches[0];
      const dx = touch.clientX - state.startX;
      const dy = touch.clientY - state.startY;

      if (!state.moved) {
        if (Math.hypot(dx, dy) < 4) return;
        state.moved = true;
      }

      const plotWidth = inst.bbox?.width ?? ((containerRef.current?.clientWidth ?? 600) - yAxisSizeRef.current);
      const plotHeight = inst.bbox?.height ?? (height - xAxisSizeRef.current);
      const [newXMin, newXMax] = panRange(state.startXMin, state.startXMax, -dx / plotWidth, xScaleType);
      setXMin(newXMin);
      setXMax(newXMax);
      inst.setScale('x', { min: newXMin, max: newXMax });

      {
        const [newYMin, newYMax] = panRange(state.startYMin, state.startYMax, dy / plotHeight, yScaleType);
        setYMin(newYMin);
        setYMax(newYMax);
        inst.setScale('y', { min: newYMin, max: newYMax });
      }
    },
    [height, xScaleType, yScaleType],
  );

  const handleTouchEnd = useCallback(() => {
    if (panStateRef.current) panStateRef.current.dragging = false;
  }, []);

  const handleWheel = useCallback(
    (e: WheelEvent) => {
      const inst = chartInstanceRef.current;
      const container = containerRef.current;
      if (!inst || !container) return;

      const rect = container.getBoundingClientRect();
      const plotLeft = inst.bbox?.left ?? 0;
      const plotTop = inst.bbox?.top ?? 0;
      const plotWidth = inst.bbox?.width ?? container.clientWidth - yAxisSizeRef.current;
      const plotHeight = inst.bbox?.height ?? (height - xAxisSizeRef.current);

      const mousePlotX = e.clientX - rect.left - plotLeft;
      const mousePlotY = e.clientY - rect.top - plotTop;

      if (mousePlotX < 0 || mousePlotX > plotWidth || mousePlotY < 0 || mousePlotY > plotHeight) {
        return;
      }

      e.preventDefault();

      const cursorXVal = inst.posToVal(mousePlotX, 'x');
      const cursorYVal = inst.posToVal(mousePlotY, 'y');
      if (!Number.isFinite(cursorXVal)) return;

      const zoomFactor = e.deltaY < 0 ? 0.88 : 1.14;

      const xScale = inst.scales?.x;
      const yScale = inst.scales?.y;
      if (!xScale || xScale.min == null || xScale.max == null) return;

      const currentXMin = xScale.min;
      const currentXMax = xScale.max;
      const [newXMin, newXMax] = zoomRange(currentXMin, currentXMax, cursorXVal, zoomFactor, xScaleType);

      if (Number.isFinite(newXMin) && Number.isFinite(newXMax) && newXMin < newXMax) {
        setXMin(newXMin);
        setXMax(newXMax);
        inst.setScale('x', { min: newXMin, max: newXMax });
      }

      if (yScale && yScale.min != null && yScale.max != null && Number.isFinite(cursorYVal)) {
        const currentYMin = yScale.min;
        const currentYMax = yScale.max;
        const [newYMin, newYMax] = zoomRange(currentYMin, currentYMax, cursorYVal, zoomFactor, yScaleType);

        if (Number.isFinite(newYMin) && Number.isFinite(newYMax) && newYMin < newYMax) {
          setYMin(newYMin);
          setYMax(newYMax);
          inst.setScale('y', { min: newYMin, max: newYMax });
        }
      }
    },
    [height, xScaleType, yScaleType],
  );

  const addListener = useCallback(
    <T extends Event>(
      target: EventTarget | null,
      type: string,
      handler: (evt: T) => void,
      options?: boolean | AddEventListenerOptions,
    ) => {
      if (!target) return;
      const wrapped = (evt: Event) => handler(evt as T);
      target.addEventListener(type, wrapped, options);
      listenersRef.current.push(() => target.removeEventListener(type, wrapped, options));
    },
    [],
  );

  useEffect(() => {
    if (!loaded || !containerRef.current) return;
    const container = containerRef.current;

    addListener(window, 'resize', onResize);

    // ResizeObserver for reliable container-level resize detection
    let resizeObserver: ResizeObserver | undefined;
    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => onResize());
      resizeObserver.observe(container);
    }

    addListener(container, 'wheel', handleWheel, { passive: false });

    if (inspectable) {
      addListener(container, 'click', handleContainerClick);
    }

    if (interactionMode !== 'zoom') {
      addListener(container, 'mousedown', handlePanDown);
      addListener(window, 'mousemove', handlePanMove);
      addListener(window, 'mouseup', handlePanUp);
      addListener(container, 'touchstart', handleTouchStart, { passive: false });
      addListener(window, 'touchmove', handleTouchMove, { passive: false });
      addListener(window, 'touchend', handleTouchEnd);
    }

    return () => {
      resizeObserver?.disconnect();
      listenersRef.current.forEach((unsub) => unsub());
      listenersRef.current = [];
    };
  }, [
    loaded,
    inspectable,
    interactionMode,
    handleContainerClick,
    handlePanDown,
    handlePanMove,
    handlePanUp,
    handleTouchStart,
    handleTouchMove,
    handleTouchEnd,
    handleWheel,
    addListener,
  ]);

  // -----------------------------------------------------------------------
  // Chart destruction happens in Effect 2's cleanup (structural change or
  // unmount). No separate effect is needed.
  // -----------------------------------------------------------------------

  const handleResetView = useCallback(() => {
    const inst = chartInstanceRef.current;
    if (!inst) return;
    try {
      // Clear manual limits so the graph autoscales to fit the data.
      setXMin(null);
      setXMax(null);
      setYMin(null);
      setYMax(null);
      applyAutoscale(inst, config.series, xScaleType, yScaleType);
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Failed to reset view');
      console.error('[EngineeringPlot] Reset view failed:', err);
      setInitError(err);
    }
  }, [validateData, config.series, xScaleType, yScaleType]);

  const handleAutoscale = useCallback(() => {
    const inst = chartInstanceRef.current;
    if (!inst || !inst.setScale) return;
    const validation = validateData(config.series);
    if (!validation.valid) return;
    try {
      setXMin(null);
      setXMax(null);
      setYMin(null);
      setYMax(null);
      applyAutoscale(inst, config.series, xScaleType, yScaleType);
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Failed to autoscale');
      console.error('[EngineeringPlot] Autoscale failed:', err);
      setInitError(err);
    }
  }, [validateData, config.series, xScaleType, yScaleType]);

  const handleResetSettings = useCallback(() => {
    setShowGrid(true);
    setYScaleType(config.yAxis.type ?? 'linear');
    setXMin(null);
    setXMax(null);
    setYMin(null);
    setYMax(null);
    setShowMarkers(false);
    setLineWidth(2);
    setShowLegend(true);
    setEnableGlow(true);
    setShowAreaShading(true);
    setSeriesVisibility({});
    setSigFigs(4);
    setCursorReadoutEnabled(config.tooltips !== false);
  }, [config.tooltips, config.yAxis.type]);

  const handleExportPng = useCallback(() => {
    const inst = chartInstanceRef.current;
    if (!inst) return;
    try {
      const canvas = containerRef.current?.querySelector<HTMLCanvasElement>('canvas');
      if (!canvas) return;
      const url = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = url;
      a.download = `${(config.title || 'plot').replace(/\s+/g, '_')}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (error) {
      const err = error instanceof Error ? error : new Error('PNG export failed');
      console.error('[EngineeringPlot] PNG export failed:', err);
      setInitError(err);
    }
  }, [config.title]);

  const handleExportCsv = useCallback(() => {
    const series = config.series;
    const maxLen = Math.max(...series.map((s) => s.x.length));
    const header = ['x', ...series.map((s) => s.label)].join(',');
    const rows: string[] = [header];
    for (let i = 0; i < maxLen; i++) {
      const yValues = series.map((s) => s.y[i] ?? '');
      rows.push(`${series[0]?.x[i] ?? ''},${yValues.join(',')}`);
    }
    const csv = rows.join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(config.title || 'plot').replace(/\s+/g, '_')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [config.series, config.title]);

  const extent = computeDataExtent(config.series, xScaleType, yScaleType);
  const datasetRange = config.series.length
    ? { xMin: extent.x[0], xMax: extent.x[1], yMin: extent.y[0], yMax: extent.y[1] }
    : null;

  if (loadError) {
    return (
      <div className={`eng-plot eng-plot-error ${className || ''}`} role="alert" aria-live="polite">
        <p>Unable to load the interactive plot.</p>
        <p className="eng-plot-error-detail">{loadError.message}</p>
        <button type="button" onClick={retryLoad} aria-label="Retry loading plot">
          Retry
        </button>
      </div>
    );
  }

  if (!loaded) {
    return (
      <div className={`eng-plot eng-plot-loading ${className || ''}`} style={{ height }} aria-label="Plot loading">
        <p>Loading plot…</p>
      </div>
    );
  }

  const { primary, comparison } = inspection;

  const renderModebar = () => (
    <div
      className={`eng-plot-modebar eng-modebar-${toolbar} ${showExportMenu ? 'has-open-menu' : ''}`}
      role="toolbar"
      aria-label="Plot controls"
    >
      {toolbar !== 'minimal' && (
        <div className="eng-modebar-group eng-plot-mode-group" role="group" aria-label="Interaction mode">
          <button
            type="button"
            className={`eng-modebar-btn eng-plot-mode-btn ${interactionMode === 'zoom' ? 'eng-modebar-active eng-plot-mode-active' : ''}`}
            onClick={() => setInteractionMode(interactionMode === 'zoom' ? 'inspect' : 'zoom')}
            data-tooltip="Box Zoom"
            data-tooltip-shortcut="Z"
            data-tooltip-subtitle="Click and drag to zoom into a region"
            data-tooltip-pos="bottom"
            aria-label="Box Zoom"
            aria-pressed={interactionMode === 'zoom'}
          >
            <ZoomIcon />
            <span className="eng-modebar-sr">Zoom</span>
          </button>
          <button
            type="button"
            className={`eng-modebar-btn eng-plot-mode-btn ${interactionMode === 'pan' ? 'eng-modebar-active eng-plot-mode-active' : ''}`}
            onClick={() => setInteractionMode(interactionMode === 'pan' ? 'inspect' : 'pan')}
            data-tooltip="Pan View"
            data-tooltip-shortcut="P"
            data-tooltip-subtitle="Click and drag to pan across axes"
            data-tooltip-pos="bottom"
            aria-label="Pan"
            aria-pressed={interactionMode === 'pan'}
          >
            <PanIcon />
            <span className="eng-modebar-sr">Pan</span>
          </button>
          <button
            type="button"
            className="eng-modebar-btn"
            onClick={handleResetView}
            data-tooltip="Reset View"
            data-tooltip-shortcut="Dbl-click"
            data-tooltip-subtitle="Restore default autoscale extent"
            data-tooltip-pos="bottom"
            aria-label="Reset View"
          >
            <ResetIcon />
            <span className="eng-modebar-sr">Reset View</span>
          </button>
          <button
            type="button"
            className="eng-modebar-btn"
            onClick={handleAutoscale}
            data-tooltip="Autoscale"
            data-tooltip-subtitle="Fit both axes tightly to data"
            data-tooltip-pos="bottom"
            aria-label="Autoscale"
          >
            <CrosshairIcon />
            <span className="eng-modebar-sr">Autoscale</span>
          </button>
        </div>
      )}

      {toolbar === 'minimal' && (
        <div className="eng-modebar-group eng-plot-mode-group" role="group" aria-label="Interaction mode">
          <button
            type="button"
            className="eng-modebar-btn"
            onClick={handleResetView}
            data-tooltip="Reset View"
            data-tooltip-shortcut="Dbl-click"
            data-tooltip-subtitle="Restore default autoscale extent"
            data-tooltip-pos="bottom"
            aria-label="Reset View"
          >
            <ResetIcon />
            <span className="eng-modebar-sr">Reset View</span>
          </button>
        </div>
      )}

      <div className="eng-modebar-group eng-plot-settings-group" role="group" aria-label="Plot actions">
        <button
          type="button"
          className={`eng-modebar-btn eng-plot-settings-btn ${showSettings ? 'eng-modebar-active' : ''}`}
          aria-expanded={showSettings}
          aria-controls={settingsPanelId}
          onClick={() => setShowSettings((value) => !value)}
          data-tooltip="Plot Settings"
          data-tooltip-subtitle="Grid, lines, markers, glow & precision"
          data-tooltip-pos="bottom"
          aria-label="Graph settings"
        >
          <SettingsIcon />
          <span className="eng-modebar-sr">Graph Settings ⚙</span>
        </button>

        <div className="eng-modebar-export-wrapper" ref={exportMenuRef}>
          <button
            type="button"
            className={`eng-modebar-btn ${showExportMenu ? 'eng-modebar-active' : ''}`}
            onClick={() => setShowExportMenu((value) => !value)}
            data-tooltip="Export Data"
            data-tooltip-subtitle="Download high-resolution PNG or CSV"
            data-tooltip-pos="bottom"
            aria-label="Export options"
            aria-haspopup="true"
            aria-expanded={showExportMenu}
          >
            <DownloadIcon />
            <span className="eng-modebar-sr">Export</span>
          </button>

          {showExportMenu && (
            <div className="eng-modebar-popover" role="menu">
              <button
                type="button"
                role="menuitem"
                className="eng-popover-item"
                onClick={() => {
                  handleExportPng();
                  setShowExportMenu(false);
                }}
                aria-label="Export plot as PNG"
              >
                Export PNG
              </button>
              <button
                type="button"
                role="menuitem"
                className="eng-popover-item"
                onClick={() => {
                  handleExportCsv();
                  setShowExportMenu(false);
                }}
                aria-label="Export data as CSV"
              >
                Export CSV
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <section className={`eng-plot ${className || ''}`} aria-label={config.title || 'Engineering plot'}>
      {initError && <div className="eng-plot-error" role="alert">
        <p>Unable to render the interactive plot. {initError.message}</p>
        <button type="button" onClick={initChart}>Retry rendering plot</button>
        <button type="button" onClick={handleResetSettings}>Reset settings</button>
      </div>}
      <header className="eng-plot-header">
        <div className="eng-plot-header-main">
          {config.title && <h2 className="eng-plot-title">{renderMathText(config.title)}</h2>}
          {toolbar === 'compact' && renderModebar()}
        </div>
        <div className="eng-plot-units">
          {renderMathText(config.xAxis.title)}{config.xAxis.unit && config.xAxis.unit !== '-' ? ` [${config.xAxis.unit}]` : ''}&nbsp;·&nbsp;
          {renderMathText(config.yAxis.title)}{config.yAxis.unit && config.yAxis.unit !== '-' ? ` [${config.yAxis.unit}]` : ''}
        </div>
        {config.description && <p className="eng-plot-description">{renderMathText(config.description)}</p>}
      </header>

      <div
        className={`eng-plot-viewport mode-${interactionMode}`}
        role="region"
        aria-label={config.title || 'Engineering plot'}
        onDoubleClick={handleResetView}
        title="Double-click chart to reset view"
      >
        <div
          ref={containerRef}
          className="eng-plot-canvas-wrapper"
          style={{ width: '100%', minHeight: height, position: 'relative', visibility: initError ? 'hidden' : 'visible' }}
          aria-hidden="true"
        />
        {(toolbar === 'floating' || toolbar === 'minimal') && renderModebar()}
      </div>

      {tooltipsEnabled && (
        <div className={`eng-plot-readout ${!hoverReadout ? 'eng-plot-readout-idle' : ''}`} aria-live="polite">
          {hoverReadout ? (
            <>
              <span className="eng-plot-readout-label">{hoverReadout.x}</span>
              {hoverReadout.series.map((entry) => (
                <span key={entry.label} className="eng-plot-readout-series">
                  <span
                    className="eng-plot-readout-marker"
                    style={{ background: entry.color, boxShadow: `0 0 0 1px ${entry.color}` }}
                    aria-hidden="true"
                  />
                  {entry.label}: {entry.value}
                </span>
              ))}
            </>
          ) : (
            <span className="eng-plot-readout-hint">
              <span className="eng-plot-readout-dot" aria-hidden="true"></span>
              Hover curve to inspect values · Click to lock operating point
            </span>
          )}
        </div>
      )}

      {showSettings && (
        <div id={settingsPanelId} className="eng-plot-settings-panel" role="region" aria-label="Graph settings">
          <div className="eng-plot-settings-section">
            <h4 className="eng-plot-settings-section-title">Axes</h4>
            <div className="eng-plot-settings-row">
              <label>
                <input
                  type="checkbox"
                  checked={showGrid}
                  onChange={(e) => setShowGrid(e.target.checked)}
                />
                Show grid
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={yScaleType === 'log'}
                  onChange={(e) => setYScaleType(e.target.checked ? 'log' : 'linear')}
                />
                Logarithmic Y axis
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={cursorReadoutEnabled}
                  onChange={(e) => setCursorReadoutEnabled(e.target.checked)}
                />
                Cursor readout
              </label>
            </div>
            <div className="eng-plot-settings-row">
              <label className="eng-plot-settings-label">X min</label>
              <input
                type="number"
                value={xMin ?? ''}
                onChange={(e) => setXMin(e.target.value === '' ? null : Number(e.target.value))}
                className="eng-plot-settings-input"
                placeholder="auto"
              />
              <label className="eng-plot-settings-label">X max</label>
              <input
                type="number"
                value={xMax ?? ''}
                onChange={(e) => setXMax(e.target.value === '' ? null : Number(e.target.value))}
                className="eng-plot-settings-input"
                placeholder="auto"
              />
              <label className="eng-plot-settings-label">Y min</label>
              <input
                type="number"
                value={yMin ?? ''}
                onChange={(e) => setYMin(e.target.value === '' ? null : Number(e.target.value))}
                className="eng-plot-settings-input"
                placeholder="auto"
              />
              <label className="eng-plot-settings-label">Y max</label>
              <input
                type="number"
                value={yMax ?? ''}
                onChange={(e) => setYMax(e.target.value === '' ? null : Number(e.target.value))}
                className="eng-plot-settings-input"
                placeholder="auto"
              />
            </div>
          </div>

          <div className="eng-plot-settings-section">
            <h4 className="eng-plot-settings-section-title">Appearance</h4>
            <div className="eng-plot-settings-row">
              <label>
                <input
                  type="checkbox"
                  checked={showMarkers}
                  onChange={(e) => setShowMarkers(e.target.checked)}
                />
                Show data markers
              </label>
              <label className="eng-plot-settings-label">Line thickness</label>
              <input
                type="range"
                min="1"
                max="6"
                step="1"
                value={lineWidth}
                onChange={(e) => setLineWidth(Number(e.target.value))}
                className="eng-plot-settings-range"
              />
              <span className="eng-plot-settings-value">{lineWidth} px</span>
              <label>
                <input
                  type="checkbox"
                  checked={showLegend}
                  onChange={(e) => setShowLegend(e.target.checked)}
                />
                Show legend
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={enableGlow}
                  onChange={(e) => setEnableGlow(e.target.checked)}
                />
                Curve glow effect
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={showAreaShading}
                  onChange={(e) => setShowAreaShading(e.target.checked)}
                />
                Area gradient shading
              </label>
            </div>
            <div className="eng-plot-settings-row">
              <label className="eng-plot-settings-label">Precision</label>
              <select
                value={sigFigs}
                onChange={(e) => setSigFigs(Number(e.target.value) as Precision)}
                className="eng-plot-settings-select"
              >
                {Object.entries(PRECISION_LABELS).map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="eng-plot-settings-section">
            <h4 className="eng-plot-settings-section-title">Series visibility</h4>
            <div className="eng-plot-settings-series">
              {config.series.map((series) => (
                <label key={series.id} className="eng-plot-settings-series-label">
                  <input
                    type="checkbox"
                    checked={seriesVisibility[series.id] !== false}
                    onChange={(e) =>
                      setSeriesVisibility((prev) => ({
                        ...prev,
                        [series.id]: e.target.checked,
                      }))
                    }
                  />
                  <span
                    className="eng-plot-settings-series-color"
                    style={{ background: series.color || themeAccent(themeRef.current) }}
                  />
                  {series.label}
                </label>
              ))}
            </div>
          </div>

          {datasetRange && (
            <div className="eng-plot-settings-section">
              <h4 className="eng-plot-settings-section-title">Data</h4>
              <div className="eng-plot-settings-row">
                <span className="eng-plot-settings-label">X range:</span>
                <span className="eng-plot-settings-value">
                  {formatAxisValue(datasetRange.xMin, config.xAxis.unit, sigFigs)} to{' '}
                  {formatAxisValue(datasetRange.xMax, config.xAxis.unit, sigFigs)}
                </span>
                <span className="eng-plot-settings-label">Y range:</span>
                <span className="eng-plot-settings-value">
                  {formatAxisValue(datasetRange.yMin, config.yAxis.unit, sigFigs)} to{' '}
                  {formatAxisValue(datasetRange.yMax, config.yAxis.unit, sigFigs)}
                </span>
              </div>
              <button type="button" onClick={handleResetSettings} className="eng-plot-settings-reset">
                Reset Settings
              </button>
            </div>
          )}
        </div>
      )}

      {inspectable && (primary || comparison) && (
        <EngineeringPointInspector
          primary={primary ?? null}
          comparison={comparison ?? null}
          metrics={inspectorMetrics}
          metricValues={inspectorMetricValues}
          comparisonValues={inspectorComparisonValues}
          xUnit={config.xAxis.unit}
          yUnit={config.yAxis.unit}
          sigFigs={sigFigs}
          onClear={() => setInspection({ primary: null, comparison: null })}
        />
      )}

      <footer className="eng-plot-footer">
        {datasetRange && (
          <>
            <span className="eng-plot-footer-label">X:</span>
            <span className="eng-plot-footer-value">{formatAxisValue(datasetRange.xMin, config.xAxis.unit, sigFigs)} — {formatAxisValue(datasetRange.xMax, config.xAxis.unit, sigFigs)}</span>
            <span className="eng-plot-footer-label">Y:</span>
            <span className="eng-plot-footer-value">{formatAxisValue(datasetRange.yMin, config.yAxis.unit, sigFigs)} — {formatAxisValue(datasetRange.yMax, config.yAxis.unit, sigFigs)}</span>
          </>
        )}
      </footer>
    </section>
  );
}
